"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
var _02_herencia_1 = require("./02_herencia"); //IMPORTO AUTO
var a1 = new _02_herencia_1.Auto("MARRON", 523000, "RENAULT");
console.log(a1.Mostrar());
a1.Precio = 65300;
console.log(a1.Precio);
//# sourceMappingURL=07_main.js.map