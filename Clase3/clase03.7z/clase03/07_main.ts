import {Auto} from "./02_herencia";//IMPORTO AUTO

let a1 = new Auto("MARRON", 523000, "RENAULT");

console.log(a1.Mostrar());

a1.Precio = 65300;

console.log(a1.Precio);
