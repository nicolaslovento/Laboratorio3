$(document).ready(function()
{
    $("#login-form").bootstrapValidator(
        {
            message: "Error",
            feedbackIcons:{
                valid: 'glyphicon glyphicon-ok', //Nombre de icono
                invalid: 'glyphicon glyphicon-remove',//Nombre de icono
            },

            fields:{
                username:{ //Aca va el name del input, no el ID!!!
                    validators:{
                        stringLength: {
                            min: 6,
                            max: 30,
                            message: 'El nombre de usuario debe contener entre 6 y 30 caracteres.'
                        },
                    }
                },
                password:{ //Aca va el name del input, no el ID!!!
                    validators:{
                        stringLength: {
                            min: 6,
                            max: 20,
                            message: 'La contraseña debe contener entre 6 y 20 caracteres.'
                        },
                    }
                }
            }
        }      
    );
});
